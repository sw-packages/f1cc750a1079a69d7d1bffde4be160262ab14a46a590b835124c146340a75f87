#pragma sw header on

#pragma sw require header org.sw.demo.google.protobuf.protoc

static void gen_grpc_cpp(const DependencyPtr &protobuf_base, const DependencyPtr &grpc_cpp_plugin,
    NativeExecutedTarget &t, const path &f, const ProtobufData &data = {})
{
    auto [protoc, _] = gen_protobuf_cpp(protobuf_base, t, f, data);

    ProtocData d = data;
    d.input = f;
    d.generator = "grpc";
    d.exts = {".grpc.pb.cc", ".grpc.pb.h"};
    d.plugin = grpc_cpp_plugin;
    d.generate(protoc, t);
}

#pragma sw header off

void build(Solution &s)
{
    auto &p = s.addProject("google.grpc", "1.84.1");
    p += Git("https://chromium.googlesource.com/external/github.com/grpc/grpc", "v{v}");

    auto cppstd = cpp20;

    auto &core = p.addStaticLibrary("core.lib");

    auto &dupb = p.addDirectory("third_party.upb");
    auto &upb = dupb.addStaticLibrary("upb");
    {
        upb.setRootDirectory("third_party");
        upb += "upb/upb/.*"_rr;
        upb -= "upb/upb/.*test.*"_rr;
        upb -= "upb/upb/.*benchmark.*"_rr;
        upb -= "upb/upb/cmake/.*"_rr;
        upb -= "upb/upb/conformance/.*"_rr;
        upb -= "upb/upb/wire/decode_fast/.*"_rr;
        //upb -= "upb/upb/reflection/.*"_rr;
        //upb -= "upb/upb/reflection/internal/.*"_rr;
        upb -= "upb/upb/reflection/stage0/google/protobuf/descriptor.upb.c";
        upb += "UPB_BOOTSTRAP_STAGE0"_def;
        upb.Public += "."_idir;
        upb.Public += "upb"_idir;
        //upb += "upb/upb/reflection/stage0"_idir;
        upb += "upb/upb/reflection/cmake"_idir;
        //upb.Public += "org.sw.demo.google.protobuf.protobuf"_dep;
        //(upb + core)->IncludeDirectoriesOnly = true;
        //upb.Public += "org.sw.demo.google.protocolbuffers.utf8_range-main"_dep;
        upb.Public += "org.sw.demo.google.protobuf.utf8_range"_dep;
        //upb += "utf8_range/utf8_range.*"_rr;
        //upb.Public += "utf8_range"_idir;
        // or change to float
        upb.patch("upb/upb/message/internal/message.c", "const double kUpb_NaN = NAN;", "//const  double kUpb_NaN = NAN;");
    }

    auto &grpc_address_sorting = p.addStaticLibrary("third_party.address_sorting");
    {
        auto &t = grpc_address_sorting;
        t += cppstd;
        t += "third_party/address_sorting/.*\\.[hc]"_rr;
        t.Public += "third_party/address_sorting/include"_idir;
    }

    auto &proto_pb = p.addStaticLibrary("proto.pb");
    {
        auto &t = proto_pb;
        t += cppstd;
        t += "src/proto/.*\\.proto"_rr;
        //t -= "src/proto/grpc/.*\\.proto"_rr; // we gen for grpc as well
        t -= "src/proto/grpc/testing/.*\\.proto"_rr;
        t -= "src/proto/grpc/status/.*\\.proto"_rr;
        t += "src/core/ext/transport/chaotic_good/chaotic_good_frame.proto"_rr;
        ProtobufData d;
        d.public_protobuf = true;
        for (auto &[p, sf] : t["src/.*\\.proto"_rr])
        {
            if (sf->skip)
                continue;
            gen_protobuf_cpp("org.sw.demo.google.protobuf"_dep, t, p, d);
        }
    }

    // core
    {
        auto &t = core;
        t += cppstd;
        t += "include/.*"_rr;
        t += "src/core/lib/.*"_rr;
        t += "src/core/ext/upb-gen/.*"_rr;
        t += "src/core/ext/upbdefs-gen/.*"_rr;
        t += "src/core/ext/filters/fault_injection/.*"_rr;
        t += "src/core/ext/filters/gcp_authentication/.*"_rr;
        t += "src/core/ext/filters/rbac/.*"_rr;
        t += "src/core/ext/filters/stateful_session/.*"_rr;
        t += "src/core/call/.*"_rr;
        t += "src/core/client_channel/.*"_rr;
        t += "src/core/config/.*"_rr;
        t += "src/core/filter/.*"_rr;
        t += "src/core/service_config/.*"_rr;
        t += "src/core/resolver/.*"_rr;
        t += "src/core/channelz/.*"_rr;
        t += "src/core/handshaker/.*"_rr;
        t += "src/core/server/.*"_rr;
        t += "src/core/xds/.*"_rr;
        t += "src/core/util/.*"_rr;
        t += "src/core/telemetry/.*"_rr;
        t += "src/core/credentials/.*"_rr;
        t += "src/core/transport/.*"_rr;
        t += "src/core/net/.*"_rr;
        t += "src/core/mitigation_engine/.*"_rr;
        //t -= "src/core/resolver/xds/.*"_rr;
        t += "src/core/load_balancing/.*"_rr;
        //t -= "src/core/load_balancing/xds/.*"_rr;
        t += "GRPC_NO_FILTER_FUSION"_def;
        //t -= "src/core/filter/fused_filters.cc";
        t -= "src/core/call/metadata_channelz.cc";

        //if (t.getBuildSettings().TargetOS.Type == OSType::Windows)
            //t.Public += "_WIN32_WINNT=0x0601"_def;

        t.Public += "include"_id;
        t.Public += "."_id;
        t.Public += "src/core/ext/upb-gen"_idir;
        t.Public += "src/core/ext/upbdefs-gen"_idir;

        t.Public += "org.sw.demo.madler.zlib"_dep;
        t.Public += "org.sw.demo.openssl.ssl"_dep;
        t.Public += "org.sw.demo.nanopb"_dep;
        t.Public += "org.sw.demo.google.abseil"_dep;
        t.Public += "org.sw.demo.opentelemetry"_dep;
        t.Public += "org.sw.demo.google.re2"_dep;
        t.Public += "GRPC_ARES"_def;
        t.Public += "org.sw.demo.c_ares"_dep;
        t.Public += upb;
        t.Public += proto_pb;
        t.Public += grpc_address_sorting;
        //t.Public += "org.sw.demo.google.protobuf.upb"_dep;

        t.patch("include/grpc/impl/codegen/port_platform.h",
            "#if !(defined(__has_feature) && __has_feature(cxx_thread_local))",
            "#if 1//!(defined(__has_feature) && __has_feature(cxx_thread_local))"
        );

        t -= "src/core/lib/event_engine/windows/.*"_rr;
        t -= "src/core/lib/event_engine/posix_engine/.*"_rr;
        if (t.getBuildSettings().TargetOS.is(OSType::Windows)) {
            t += "src/core/lib/event_engine/windows/.*"_rr;
        } else {
            t += "src/core/lib/event_engine/posix_engine/.*"_rr;
        }
        if (t.getBuildSettings().TargetOS.isApple()) {
            t -= "src/core/lib/event_engine/cf_engine/.*"_rr;
            t.add("src/core/lib/event_engine/cf_engine/cf_engine.cc", ".mm");
            t.add("src/core/lib/event_engine/cf_engine/cfstream_endpoint.cc", ".mm");
            t.add("src/core/lib/event_engine/cf_engine/dns_service_resolver.cc", ".mm");
        }
        t += "src/core/lib/event_engine/posix_engine/timer.*"_rr;

        // openssl 4
        //t.patch("src/core/credentials/transport/tls/grpc_tls_crl_provider.cc", "X509_NAME*", "auto");
        // or use GRPC_CPU_INTENSIVE_BITGEN?
        t.patch("src/core/util/shared_bit_gen.h", "return bit_gen_();", "return bit_gen_()();");
        t.patch("src/core/util/shared_bit_gen.h", "static thread_local absl::BitGen bit_gen_;", "static absl::BitGen &bit_gen_();");
        t.patch("src/core/util/shared_bit_gen.cc", "thread_local absl::BitGen SharedBitGen::bit_gen_;", R"(//thread_local absl::BitGen SharedBitGen::bit_gen_ ;
absl::BitGen &SharedBitGen::bit_gen_() {
    thread_local absl::BitGen g;
    return g;
}
)");
        //t.pushFrontToFileOnce("src/core/util/shared_bit_gen.cc", "#include <mutex>");
        /*t.patch("src/core/util/shared_bit_gen.cc", "thread_local absl::BitGen SharedBitGen::bit_gen_;", R"(//thread_local absl::BitGen SharedBitGen::bit_gen_ ;
thread_local absl::BitGen SharedBitGen::bit_gen_ = [](){
    static std::mutex m;
    std::unique_lock lk{m};
    return absl::BitGen{};
}();
)");*/

        t.patch("src/core/credentials/transport/tls/grpc_tls_crl_provider.cc", "X509_NAME* issuer", "auto issuer");
    }

    auto &grpc_plugin_support = p.addStaticLibrary("plugin_support");
    {
        auto &t = grpc_plugin_support;
        t += cppstd;
        t += "src/compiler/.*\\.h"_rr;
        t += "src/compiler/.*_generator\\.cc"_rr;

        t.Public += "."_id;

        t.Public += core;
        t += "org.sw.demo.google.protobuf.protobuf"_dep;
    }

    auto &grpc_cpp_plugin = p.addExecutable("cpp.plugin");
    {
        auto &t = grpc_cpp_plugin;
        t += cppstd;
        t += "src/compiler/cpp_plugin.cc";
        t += "src/compiler/proto_parser_helper.cc";
        t += grpc_plugin_support;
        t += "org.sw.demo.google.protobuf.protoc_lib"_dep;
    }

    auto &proto_grpc = p.addStaticLibrary("proto.grpc");
    {
        auto &t = proto_grpc;
        t += cppstd;
        t += "src/proto/grpc/.*\\.proto"_rr;
        t -= "src/proto/grpc/testing/.*\\.proto"_rr;
        t -= "src/proto/grpc/status/.*\\.proto"_rr;
        t.Public += core;
        ProtobufData data;
        data.public_protobuf = true;
        for (auto &[p, sf] : t["src/.*\\.proto"_rr])
        {
            if (sf->skip)
                continue;
            //gen_grpc_cpp("org.sw.demo.google.protobuf"_dep, std::make_shared<Dependency>(grpc_cpp_plugin), t, p, data);

            ProtocData d = data;
            d.input = p;
            d.generator = "grpc";
            d.exts = {".grpc.pb.cc", ".grpc.pb.h"};
            d.plugin = std::make_shared<Dependency>(grpc_cpp_plugin);
            d.generate("org.sw.demo.google.protobuf.protoc"_dep, t);
        }
    }

    auto &core_plugin_registry = p.addStaticLibrary("core.plugin_registry");
    {
        auto &t = core_plugin_registry;
        t += cppstd;
        t += "src/core/plugin_registry/.*"_rr;

        t += "GRPC_NO_FILTER_FUSION"_def;
        t.Public += "."_id;

        t.Public += core;
    }

    auto &core_ext = p.addStaticLibrary("core.ext");
    {
        auto &t = core_ext;
        t += cppstd;
        t += "src/core/ext/.*"_rr;
        t -= "src/core/ext/upb-gen/.*"_rr;
        t -= "src/core/ext/filters/fault_injection/.*"_rr;
        t -= "src/core/ext/filters/gcp_authentication/.*"_rr;
        t -= "src/core/ext/filters/rbac/.*"_rr;
        t -= "src/core/ext/filters/stateful_session/.*"_rr;
        //t -= "src/core/ext/upbdefs-generated/.*"_rr;
        //t -= "src/core/ext/transport/cronet/plugin_registry/.*"_rr;
        //t -= "src/core/ext/filters/load_reporting/.*"_rr;
        //t += "third_party/objective_c/Cronet/.*\\.h"_rr;

        //t += "GRPC_ARES"_def;
        t.Public += "."_id;
        t += "src/core/ext/upbdefs-gen"_id;

        t.Public += proto_grpc;
        t.Public += core_plugin_registry;
        t.Public += "org.sw.demo.Cyan4973.xxHash"_dep;
        t.Public += "org.sw.demo.census.opencensus.cpp"_dep;
        (core + core_ext)->IncludeDirectoriesOnly = true;
        (core_plugin_registry + core_ext)->IncludeDirectoriesOnly = true;

        //t.patch("third_party/objective_c/Cronet/bidirectional_stream_c.h", "(WIN32)", "(_WIN32)");
    }

    auto &core_tsi = p.addStaticLibrary("core.tsi");
    {
        auto &t = core_tsi;
        t += cppstd;
        t += "src/core/tsi/.*"_rr;

        t.Public += "."_id;

        t.Public += core;
        t.Public += proto_grpc;
        (core + core_tsi)->IncludeDirectoriesOnly = true;
        (core_tsi + core_ext)->IncludeDirectoriesOnly = true;

        t.patch("src/core/tsi/ssl_transport_security_utils.cc", "X509_NAME* cert_issuer_name", "auto cert_issuer_name");
        t.patch("src/core/tsi/ssl_transport_security_utils.cc", "X509_NAME* crl_issuer_name", "auto crl_issuer_name");
        t.patch("src/core/tsi/ssl_transport_security_utils.cc", "X509_NAME* issuer", "auto issuer");
        t.patch("src/core/tsi/ssl_transport_security_utils.cc", "ASN1_OCTET_STRING* akid", "const ASN1_OCTET_STRING * akid");
        t.patch("src/core/tsi/ssl_transport_security.cc", "X509_NAME* subject_name", "auto subject_name");
        t.patch("src/core/tsi/ssl_transport_security.cc", "X509_NAME_ENTRY* common_name_entry", "const X509_NAME_ENTRY * common_name_entry");
        t.patch("src/core/tsi/ssl_transport_security.cc", "ASN1_STRING* common_name_asn1", "const ASN1_STRING * common_name_asn1");
        t.patch("src/core/tsi/ssl_transport_security.cc", "root_name = X509_get_subject_name(root);", "root_name = (X509_NAME*)X509_get_subject_name(root);");
        t.pushFrontToFileOnce("src/core/tsi/ssl_transport_security.cc", "#include <crypto/asn1.h>");
    }

    auto &cpp = p.addStaticLibrary("cpp");
    {
        auto &t = cpp;
        t += cppstd;
        t += "src/cpp/.*"_rr;
        t -= "src/cpp/common/insecure_create_auth_context.cc";
        t -= "src/cpp/server/admin/.*"_rr;
        t -= "src/cpp/server/csds/.*"_rr;
        t -= "src/cpp/ext/gcp.*"_rr;
        //t -= "src/cpp/ext/gcp/observability.*"_rr;
        t -= "src/cpp/ext/otel.*"_rr;
        t -= "src/cpp/ext/csm.*"_rr;

        t -= "src/cpp/ext/proto_server_reflection.cc";
        t -= "src/cpp/ext/proto_server_reflection_plugin.cc";
        t -= "src/cpp/server/channelz/channelz_service.cc";
        t -= "src/cpp/server/channelz/channelz_service_plugin.cc";

        t.Public += "."_id;
        t.Public += "src"_id;

        t.Public += core, core_ext, core_tsi;
        (core_ext + t)->IncludeDirectoriesOnly = true;
    }
}
